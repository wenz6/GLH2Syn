

"""
新增框架diffusion
BioEncoder
   ↓
┌───────────────┬────────────────┐
│ Topology-level│ Semantic-level │
│ Sheaf HGNN    │ Hypergraph     │
│ Encoder       │ Diffusion      │
└───────────────┴────────────────┘
           ↓ concat
        fused_embed
             ↓
          Decoder
"""

import numpy as np
import pandas as pd
import torch
import torch.utils.data as Data
from model_reg import BioEncoder, HyperGraphSynergy, HgnnEncoder, Decoder, HypergraphDiffusionEncoder
from model_reg import SheafHgnnEncoder #层次超图结构
from sklearn.model_selection import KFold
import os
import glob
import warnings
import sys

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PARENT_DIR = os.path.abspath(os.path.join(CURRENT_DIR, '..'))
if PARENT_DIR not in sys.path:
    sys.path.append(PARENT_DIR)

from drug_util import GraphDataset, collate
from utils import regression_metric, set_seed_all
from similarity import get_Cosin_Similarity, get_pvalue_matrix
from process_data import getData

warnings.filterwarnings('ignore')
device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')


def load_data(dataset):
    cline_fea, drug_fea, drug_smiles_fea, gene_data, synergy = getData(dataset)
    cline_fea = torch.from_numpy(cline_fea).to(device)

    drug_sim_matrix, cline_sim_matrix = get_sim_mat(drug_smiles_fea, np.array(gene_data, dtype='float32'))

    return drug_fea, cline_fea, synergy, drug_sim_matrix, cline_sim_matrix


def data_split(synergy, rd_seed=0):
    synergy_pos = pd.DataFrame([i for i in synergy])
    # -----split synergy into 5CV,test set （90% CV + 10% Independent Test）
    train_size = 0.9
    synergy_cv_data, synergy_test = np.split(np.array(synergy_pos.sample(frac=1, random_state=rd_seed)),
                                             [int(train_size * len(synergy_pos))])
    np.random.shuffle(synergy_cv_data)
    np.random.shuffle(synergy_test)
    np.savetxt(path + 'test_y_true.txt', synergy_test[:, 3])
    test_label = torch.from_numpy(np.array(synergy_test[:, 3], dtype='float32')).to(device)
    test_ind = torch.from_numpy(np.array(synergy_test[:, 0:3])).long().to(device)
    return synergy_cv_data, test_ind, test_label


def get_sim_mat(drug_fea, cline_fea):
    drug_sim_matrix = np.array(get_Cosin_Similarity(drug_fea))
    cline_sim_matrix = np.array(get_pvalue_matrix(cline_fea))
    return torch.from_numpy(drug_sim_matrix).type(torch.FloatTensor).to(device), torch.from_numpy(
        cline_sim_matrix).type(torch.FloatTensor).to(device)


# --train+test
def train(drug_fea_set, cline_fea_set, synergy_adj, index, label, lamda):
    loss_train = 0
    true_ls, pre_ls = [], []
    optimizer.zero_grad()
    for batch, (drug, cline) in enumerate(zip(drug_fea_set, cline_fea_set)):
        pred, rec_drug, rec_cline = model(drug.x.to(device), drug.edge_index.to(device), drug.batch.to(device),
                                          cline[0], synergy_adj,
                                          index[:, 0], index[:, 1], index[:, 2])
        loss = loss_func(pred, label)
        loss_rec_1 = rec_loss(rec_drug, drug_sim_mat)
        loss_rec_2 = rec_loss(rec_cline, cline_sim_mat)
        loss = (1 - lamda) * loss + lamda * (loss_rec_1 + loss_rec_2)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=5.0)
        optimizer.step()
        loss_train += loss.item()
        true_ls += label.cpu().detach().numpy().tolist()
        pre_ls += pred.cpu().detach().numpy().tolist()
    rmse, r2, pr = regression_metric(true_ls, pre_ls)
    return [rmse, r2, pr], loss_train

def test(drug_fea_set, cline_fea_set, synergy_adj, index, label, lamda):
    model.eval()
    with torch.no_grad():
        for batch, (drug, cline) in enumerate(zip(drug_fea_set, cline_fea_set)):
            pred, rec_drug, rec_cline = model(drug.x.to(device), drug.edge_index.to(device), drug.batch.to(device),
                                              cline[0], synergy_adj,
                                              index[:, 0], index[:, 1], index[:, 2])
        loss = loss_func(pred, label)
        # loss_rec_1 = loss_func(rec_drug, drug_sim_mat)
        # loss_rec_2 = loss_func(rec_cline, cline_sim_mat)
        loss_rec_1 = rec_loss(rec_drug, drug_sim_mat)
        loss_rec_2 = rec_loss(rec_cline, cline_sim_mat)

        loss = (1 - lamda) * loss + lamda * (loss_rec_1 + loss_rec_2)
        rmse, r2, pr = regression_metric(label.cpu().detach().numpy(),
                                         pred.cpu().detach().numpy())
        return [rmse, r2, pr], loss.item(), pred.cpu().detach().numpy()


if __name__ == '__main__':
    os.chdir(CURRENT_DIR)
    os.makedirs('result_reg', exist_ok=True)

    dataset_name = 'ONEIL'
    seed = 2026
    cv_mode_ls = [1]
    epochs = 4000
    learning_rate = 4e-3  # 降低学习率防过拟合
    L2 = 5e-4
    lamda = 0.7
    alpha = 0.3

    for cv_mode in cv_mode_ls:
        print(f'\n========== CV MODE {cv_mode} ==========')

        # 保存每折结果
        fold_results = []
        #新增独立数据集
        independent_results = []

        path = 'result_reg/' + dataset_name + '_' + str(cv_mode) + '_'
        os.makedirs(path, exist_ok=True)
        file = open(path + 'result.txt', 'w')

        set_seed_all(seed)
        drug_feature, cline_feature, synergy_data, drug_sim_mat, cline_sim_mat = load_data(dataset_name)

        drug_set = Data.DataLoader(dataset=GraphDataset(graphs_dict=drug_feature),
                                   collate_fn=collate, batch_size=len(drug_feature), shuffle=False)
        cline_set = Data.DataLoader(dataset=Data.TensorDataset(cline_feature),
                                    batch_size=len(cline_feature), shuffle=False)

        # %%-----build dataset
        # -----split synergy into 5CV,test set
        synergy_cv, index_test, label_test = data_split(synergy_data)
        if cv_mode == 1:
            cv_data = synergy_cv
        elif cv_mode == 2:
            cv_data = np.unique(synergy_cv[:, 2])  # cline_level
        else:
            cv_data = np.unique(np.vstack([synergy_cv[:, 0], synergy_cv[:, 1]]), axis=1).T  # drug pairs_level

        # ---5CV
        final_metric = np.zeros(3)
        fold_num = 0
        kf = KFold(n_splits=5, shuffle=True, random_state=seed)

        for train_index, validation_index in kf.split(cv_data):
            # ---construct train_set+validation_set
            if cv_mode == 1:  # normal_level
                synergy_train, synergy_validation = cv_data[train_index], cv_data[validation_index]
            elif cv_mode == 2:  # cell line_level
                train_name, test_name = cv_data[train_index], cv_data[validation_index]
                synergy_train = np.array([i for i in synergy_cv if i[2] in train_name])
                synergy_validation = np.array([i for i in synergy_cv if i[2] in test_name])
            else:  # drug pairs_level
                pair_train, pair_validation = cv_data[train_index], cv_data[validation_index]
                synergy_train = np.array(
                    [j for i in pair_train for j in synergy_cv if (i[0] == j[0]) and (i[1] == j[1])])
                synergy_validation = np.array(
                    [j for i in pair_validation for j in synergy_cv if (i[0] == j[0]) and (i[1] == j[1])])

            # ---construct train_set+validation_set
            np.savetxt(path + 'val_' + str(fold_num) + '_true.txt', synergy_validation[:, 3])
            label_train = torch.from_numpy(np.array(synergy_train[:, 3], dtype='float32')).to(device)
            label_validation = torch.from_numpy(np.array(synergy_validation[:, 3], dtype='float32')).to(device)

            index_train = torch.from_numpy(synergy_train[:, 0:3]).long().to(device)
            index_validation = torch.from_numpy(synergy_validation[:, 0:3]).long().to(device)

            # -----construct hyper_synergy_graph_set 构造超图
            synergy_train_tmp = np.copy(synergy_train)
            for data in synergy_train_tmp:
                data[3] = 1 if data[3] >= 30 else 0
            pos_edge = np.array([t for t in synergy_train_tmp if t[3] != 0])
            edge_data = pos_edge[:, 0:3]

            synergy_edge = edge_data.reshape(1, -1)
            index_num = np.expand_dims(np.arange(len(edge_data)), axis=-1)
            synergy_num = np.concatenate((index_num, index_num, index_num), axis=1).reshape(1, -1)
            synergy_graph = np.concatenate((synergy_edge, synergy_num), axis=0)
            synergy_graph = torch.from_numpy(synergy_graph).type(torch.LongTensor).to(device)

            # ---model_build
            # model = HyperGraphSynergy(BioEncoder(dim_drug=75, dim_cellline=cline_feature.shape[-1], output=100),
            #                           HgnnEncoder(in_channels=100, out_channels=256), Decoder(in_channels=768)).to(device)

            # #替换成sheaf hypergraph
            # drug_num = 38
            # cline_num = 32

            drug_num = drug_sim_mat.size(0)
            cline_num = cline_sim_mat.size(0)


            num_nodes = drug_num + cline_num

            # model = HyperGraphSynergy(
            #     BioEncoder(dim_drug=75, dim_cellline=cline_feature.shape[-1], output=100),
            #     SheafHgnnEncoder(
            #         in_channels=100,
            #         out_channels=256,
            #         num_nodes=num_nodes
            #     ),
            #     Decoder(in_channels=768)).to(device)

            # semantic_encoder = HypergraphDiffusionEncoder(alpha=alpha)

            model = HyperGraphSynergy(
                bio_encoder=BioEncoder(
                    dim_drug=75,
                    dim_cellline=cline_feature.shape[-1],
                    output=256  # ⚠️ 统一为 256
                ),
                topo_encoder=SheafHgnnEncoder(
                    in_channels=256,
                    out_channels=256,
                    num_nodes=num_nodes
                ),
                semantic_encoder=HypergraphDiffusionEncoder(
                    alpha=alpha
                ),
                decoder=Decoder(
                    in_channels=1536  # 3 × 256 = 768(gated)    512×3=1536（concat）
                ),
                embed_dim=256
            ).to(device)

            loss_func = torch.nn.MSELoss()
            rec_loss = torch.nn.BCELoss()
            optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate, weight_decay=L2)
            scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs)

            best_metric = [0, 0, 0]
            best_epoch = 0

            for epoch in range(epochs):
                model.train()
                train_metric, train_loss = train(drug_set, cline_set, synergy_graph,
                                                 index_train, label_train, lamda)
                val_metric, val_loss, _ = test(drug_set, cline_set, synergy_graph,
                                               index_validation, label_validation, lamda)

                if epoch % 20 == 0:
                    print('Epoch: {:05d},'.format(epoch), 'loss_train: {:.6f},'.format(train_loss),
                          'RMSE: {:.6f},'.format(train_metric[0]), 'R2: {:.6f},'.format(train_metric[1]),
                          'Pearson r: {:.6f},'.format(train_metric[2]))
                    print('Epoch: {:05d},'.format(epoch), 'loss_val: {:.6f},'.format(val_loss),
                          'RMSE: {:.6f},'.format(val_metric[0]), 'R2: {:.6f},'.format(val_metric[1]),
                          'Pearson r: {:.6f},'.format(val_metric[2]))

                if val_metric[2] > best_metric[2]:
                    best_metric = val_metric
                    best_epoch = epoch
                    torch.save(model.state_dict(), 'best_model.pth')

                scheduler.step()

            print('The best results on validation set, Epoch: {:05d},'.format(best_epoch),
                  'RMSE: {:.6f},'.format(best_metric[0]),
                  'R2: {:.6f},'.format(best_metric[1]), 'Pearson r: {:.6f},'.format(best_metric[2]))

            model.load_state_dict(torch.load('best_model.pth'))

            val_metric, _, y_val_pred = test(drug_set, cline_set, synergy_graph, index_validation,
                                             label_validation, lamda)
            test_metric, _, y_test_pred = test(drug_set, cline_set, synergy_graph, index_test,
                                               label_test, lamda)
            #独立测试集指标
            independent_results.append({
                'Fold': fold_num,
                'RMSE': test_metric[0],
                'R2': test_metric[1],
                'Pearson_r': test_metric[2]
            })

            np.savetxt(path + 'val_' + str(fold_num) + '_pred.txt', y_val_pred)
            np.savetxt(path + 'test_' + str(fold_num) + '_pred.txt', y_test_pred)
            file.write('val_metric:')

            for item in val_metric:
                file.write(str(item) + '\t')
            file.write('\ntest_metric:')

            for item in test_metric:
                file.write(str(item) + '\t')
            file.write('\n')

            fold_results.append({
                'Fold': fold_num,
                'RMSE': val_metric[0],
                'R2': val_metric[1],
                'Pearson_r': val_metric[2]
            })

            final_metric += val_metric
            fold_num = fold_num + 1



        final_metric /= 5

        print('Final 5-cv average results, RMSE: {:.6f},'.format(final_metric[0]),
              'R2: {:.6f},'.format(final_metric[1]),
              'Pearson r: {:.6f},'.format(final_metric[2]))

        # ===== 保存到 CSV（一个 cv_mode 两个文件）=====
        df = pd.DataFrame(fold_results)
        mean_row = df[['RMSE', 'R2', 'Pearson_r']].mean()
        mean_row['Fold'] = 'Mean'
        df = pd.concat([df, pd.DataFrame([mean_row])], ignore_index=True)
        df.to_csv(f'result_reg/{dataset_name}_{cv_mode}_fold_results.csv', index=False)

        #  ===== Independent Test 结果保存 =====
        df_test = pd.DataFrame(independent_results)
        mean_row_test = df_test[['RMSE', 'R2', 'Pearson_r']].mean()
        mean_row_test['Fold'] = 'Mean'
        df_test = pd.concat(
            [df_test, pd.DataFrame([mean_row_test])],
            ignore_index=True
        )
        df_test.to_csv(f'result_reg/{dataset_name}_{cv_mode}_independent_results.csv', index=False)
    print(f'\nRegression results saved to result_reg/{dataset_name}_*_*.csv')
