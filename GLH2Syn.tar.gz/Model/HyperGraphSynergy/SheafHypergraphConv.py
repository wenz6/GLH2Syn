import torch
import torch.nn as nn
import torch.nn.functional as F

try:
    from torch_geometric.utils import scatter
except ImportError:
    from torch_scatter import scatter

class SheafHypergraphConv(nn.Module):
    def __init__(self, in_channels, out_channels, num_nodes):
        super().__init__()

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.num_nodes = num_nodes

        # 共享线性变换 W
        self.lin = nn.Linear(in_channels, out_channels, bias=False)


        # 节点级 sheaf 映射 ρ_v
        self.sheaf = nn.Parameter(
            torch.Tensor(num_nodes, out_channels, out_channels)
        )

        self.reset_parameters()

    def reset_parameters(self):
        nn.init.xavier_uniform_(self.lin.weight)
        nn.init.xavier_uniform_(self.sheaf)

    def forward(self, x, hyperedge_index):
        """
        x: [N, in_channels]
        hyperedge_index: [2, E]
            row 0: node indices
            row 1: hyperedge indices
        """

        # 1. 线性变换
        x = self.lin(x)  # [N, out_channels]

        node_idx = hyperedge_index[0]
        edge_idx = hyperedge_index[1]

        # 2. node -> hyperedge 聚合
        edge_feat = scatter(
            x[node_idx],
            edge_idx,
            dim=0,
            reduce='mean'
        )  # [num_edges, out_channels]

        # 3. hyperedge -> node 回传
        msg = edge_feat[edge_idx]  # [E, out_channels]

        # 4. sheaf 映射（节点相关）
        rho = self.sheaf[node_idx]          # [E, d, d]
        msg = torch.bmm(rho, msg.unsqueeze(-1)).squeeze(-1)

        # 5. 聚合到节点
        out = scatter(
            msg,
            node_idx,
            dim=0,
            dim_size=self.num_nodes,
            reduce='mean'
        )

        return out


class SheafHypergraphConvV2(nn.Module):
    """低秩 Sheaf 超图卷积 + 残差 + 双向注意力"""
    def __init__(self, in_channels, out_channels, num_nodes, rank=64):
        super().__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.num_nodes = num_nodes
        self.rank = rank

        self.lin = nn.Linear(in_channels, out_channels, bias=False)
        # node→hyperedge 注意力
        self.attn_lin = nn.Linear(out_channels, 1)

        # 低秩 sheaf 映射: ρ_v = U_v @ V_v
        self.sheaf_u = nn.Parameter(torch.Tensor(num_nodes, out_channels, rank))
        self.sheaf_v = nn.Parameter(torch.Tensor(num_nodes, rank, out_channels))

        self.reset_parameters()

    def reset_parameters(self):
        nn.init.xavier_uniform_(self.lin.weight)
        nn.init.xavier_uniform_(self.attn_lin.weight)
        nn.init.zeros_(self.attn_lin.bias)
        nn.init.xavier_uniform_(self.sheaf_u)
        nn.init.xavier_uniform_(self.sheaf_v)

    def forward(self, x, hyperedge_index):
        identity = x
        x = self.lin(x)  # [N, out_channels]

        node_idx = hyperedge_index[0]
        edge_idx = hyperedge_index[1]

        # 1. node -> hyperedge (注意力加权聚合)
        attn_scores = self.attn_lin(x[node_idx]).squeeze(-1)  # [E]
        attn_scores = F.leaky_relu(attn_scores, 0.2)
        attn_max = scatter(attn_scores.detach(), edge_idx, dim=0, reduce='max')
        attn_exp = torch.exp(attn_scores - attn_max[edge_idx])
        attn_sum = scatter(attn_exp, edge_idx, dim=0, reduce='sum')
        attn_weights = attn_exp / (attn_sum[edge_idx] + 1e-8)
        edge_feat = scatter(
            attn_weights.unsqueeze(-1) * x[node_idx],
            edge_idx,
            dim=0,
            reduce='sum'
        )

        # 2. hyperedge -> node + 低秩 sheaf 映射
        msg = edge_feat[edge_idx]  # [E, out_channels]
        u = self.sheaf_u[node_idx]  # [E, d, r]
        v = self.sheaf_v[node_idx]  # [E, r, d]
        rho = torch.bmm(u, v)  # [E, d, d]
        msg = torch.bmm(rho, msg.unsqueeze(-1)).squeeze(-1)  # [E, d]

        # 3. 聚合到节点 (mean)
        out = scatter(
            msg,
            node_idx,
            dim=0,
            dim_size=self.num_nodes,
            reduce='mean'
        )

        # 4. 残差连接
        if self.in_channels == self.out_channels:
            out = out + identity

        return out
