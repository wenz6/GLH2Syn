import torch
import torch.nn as nn
from torch_geometric.nn import HypergraphConv, GCNConv, global_max_pool, global_mean_pool
import os
import sys
from SheafHypergraphConv import SheafHypergraphConv, SheafHypergraphConvV2
from torch_geometric.nn import GATConv #引入GAT的模块求解

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PARENT_DIR = os.path.abspath(os.path.join(CURRENT_DIR, '..'))
if PARENT_DIR not in sys.path:
    sys.path.append(PARENT_DIR)
from utils import reset

#后面已经修改成自动识别
# # #ONEIL
# drug_num = 38
# cline_num = 39

# #ALMANAC
# drug_num = 87
# cline_num = 55

import torch
import torch.nn as nn
import torch.nn.functional as F

class HypergraphDiffusionEncoder(nn.Module):
    """
    Hypergraph Diffusion Encoder
    """

    def __init__(self, alpha=0.8, eps=1e-8, dim=256):
        super().__init__()
        self.alpha = alpha
        self.eps = eps

    def forward(self, X, hyperedge_index):
        device = X.device
        N, d = X.shape

        node_idx = hyperedge_index[0]
        edge_idx = hyperedge_index[1]
        M = int(edge_idx.max()) + 1

        Y = torch.zeros(N, M, device=device)
        Y[node_idx, edge_idx] = 1.0

        A = torch.zeros(N + M, N + M, device=device)
        A[:N, N:] = Y
        A[N:, :N] = Y.t()

        deg = A.sum(dim=1)
        D_inv_sqrt = torch.pow(deg + self.eps, -0.5)
        T = D_inv_sqrt.view(-1, 1) * A * D_inv_sqrt.view(1, -1)

        I = torch.eye(N + M, device=device)
        S = self.alpha * torch.linalg.inv(I - (1 - self.alpha) * T)

        S_ne = S[N:, :N]
        S_ne = S_ne * Y.t()
        S_ne = S_ne / (S_ne.sum(dim=0, keepdim=True) + self.eps)

        H = S_ne @ X
        Z = S_ne.t() @ H

        return Z


class SheafHgnnEncoder(nn.Module):
    def __init__(self, in_channels, out_channels, num_nodes, rank=64):
        super().__init__()

        self.conv1 = SheafHypergraphConvV2(
            in_channels, 256, num_nodes, rank=rank
        )
        self.ln1 = nn.LayerNorm(256)

        self.conv2 = SheafHypergraphConvV2(
            256, out_channels, num_nodes, rank=rank
        )

        self.act = nn.LeakyReLU(0.2)
        self.drop = nn.Dropout(0.2)

    def forward(self, x, hyperedge_index):
        identity = x
        x = self.act(self.conv1(x, hyperedge_index))
        x = self.ln1(x)
        x = self.drop(x)
        x = self.act(self.conv2(x, hyperedge_index))
        if x.shape == identity.shape:
            x = x + identity
        return x



class HgnnEncoder(torch.nn.Module):
    """
    HypergraphConv → LeakyReLU → BN → Dropout
              → HypergraphConv → LeakyReLU
    """
    def __init__(self, in_channels, out_channels):
        super(HgnnEncoder, self).__init__()
        self.conv1 = HypergraphConv(in_channels, 256)
        self.batch1 = nn.BatchNorm1d(256)  # TODO HGNN 增加两层batch norm
        self.conv2 = HypergraphConv(256, out_channels)
        self.drop_out = nn.Dropout(0.3)
        self.act = nn.LeakyReLU(0.2)

    def forward(self, x, edge):
        x = self.act(self.conv1(x, edge))
        x = self.batch1(x)
        x = self.drop_out(x)
        x = self.act(self.conv2(x, edge))
        return x

# #使用了2-layer GCN
# class BioEncoder(nn.Module):
#     """
#     药物编码GCN：GCNConv → BN → Dropout → GCNConv → BN → Pooling
#     细胞系编码MLP：Linear → BN → Dropout → Linear
#     """
#     def __init__(self, dim_drug, dim_cellline, output, use_GMP=True):
#         super(BioEncoder, self).__init__()
#         # -------drug_layer
#         self.use_GMP = use_GMP
#         self.conv1 = GCNConv(dim_drug, 128)
#         self.batch_conv1 = nn.BatchNorm1d(128)
#         self.conv2 = GCNConv(128, output)
#         self.batch_conv2 = nn.BatchNorm1d(output)  # todo 新增一个batch norm
#         # -------cell line_layer
#         self.fc_cell1 = nn.Linear(dim_cellline, 128)
#         self.batch_cell1 = nn.BatchNorm1d(128)
#         self.fc_cell2 = nn.Linear(128, output)
#         self.drop_out = nn.Dropout(0.3)
#         self.act = nn.ReLU()
#
#     def forward(self, drug_feature, drug_adj, ibatch, gexpr_data):
#         # -----drug_train
#         x_drug = self.conv1(drug_feature, drug_adj)
#         x_drug = self.batch_conv1(self.act(x_drug))
#         x_drug = self.drop_out(x_drug)
#         x_drug = self.conv2(x_drug, drug_adj)
#         x_drug = self.batch_conv2(self.act(x_drug))
#         if self.use_GMP:
#             x_drug = global_max_pool(x_drug, ibatch)
#         else:
#             x_drug = global_mean_pool(x_drug, ibatch)
#         # ----cellline_train
#         x_cellline = torch.tanh(self.fc_cell1(gexpr_data))
#         x_cellline = self.batch_cell1(x_cellline)
#         x_cellline = self.drop_out(x_cellline)
#         x_cellline = self.act(self.fc_cell2(x_cellline))
#         return x_drug, x_cellline
class BioEncoder(nn.Module):
    """
    Drug encoder: 2-layer GAT
    Cell line encoder: MLP
    """
    def __init__(self, dim_drug, dim_cellline, output, use_GMP=True):
        super(BioEncoder, self).__init__()
        self.use_GMP = use_GMP

        self.gat1 = GATConv(dim_drug, 128, heads=4, concat=True, dropout=0.3)
        self.batch_gat1 = nn.BatchNorm1d(128 * 4)
        self.gat2 = GATConv(128 * 4, output, heads=1, concat=False, dropout=0.3)
        self.batch_gat2 = nn.BatchNorm1d(output)

        self.fc_cell1 = nn.Linear(dim_cellline, 128)
        self.batch_cell1 = nn.BatchNorm1d(128)
        self.fc_cell2 = nn.Linear(128, output)

        self.drop_out = nn.Dropout(0.3)
        self.act = nn.ReLU()

    def forward(self, drug_feature, drug_adj, ibatch, gexpr_data):
        x_drug = self.gat1(drug_feature, drug_adj)
        x_drug = self.batch_gat1(self.act(x_drug))
        x_drug = self.drop_out(x_drug)
        x_drug = self.gat2(x_drug, drug_adj)
        x_drug = self.batch_gat2(self.act(x_drug))
        if self.use_GMP:
            x_drug = global_max_pool(x_drug, ibatch)
        else:
            x_drug = global_mean_pool(x_drug, ibatch)

        x_cellline = torch.tanh(self.fc_cell1(gexpr_data))
        x_cellline = self.batch_cell1(x_cellline)
        x_cellline = self.drop_out(x_cellline)
        x_cellline = self.act(self.fc_cell2(x_cellline))

        return x_drug, x_cellline


class Decoder(torch.nn.Module):
    """
    协同效应回归头
    h = concat(drugA, drugB, cell)→ FC → BN → Dropout → FC → BN → Dropout → FC
    """
    def __init__(self, in_channels):
        super(Decoder, self).__init__()
        self.fc1 = nn.Linear(in_channels, in_channels // 2)
        self.batch1 = nn.BatchNorm1d(in_channels // 2)
        self.fc2 = nn.Linear(in_channels // 2, in_channels // 4)
        self.batch2 = nn.BatchNorm1d(in_channels // 4)
        self.fc3 = nn.Linear(in_channels // 4, 1)
        self.drop_out = nn.Dropout(0.3)
        self.act = nn.LeakyReLU(0.2)

    def forward(self, graph_embed, druga_id, drugb_id, cellline_id):
        h = torch.cat((graph_embed[druga_id, :], graph_embed[drugb_id, :], graph_embed[cellline_id, :]), 1)
        h = self.act(self.fc1(h))
        h = self.batch1(h)
        h = self.drop_out(h)
        h = self.act(self.fc2(h))
        h = self.batch2(h)
        h = self.drop_out(h)
        h = self.fc3(h)
        return h.squeeze(dim=1)

class HyperGraphSynergy(nn.Module):
    """
    HyperGraphSynergy with
            - Topology-level: Sheaf Hypergraph
            - Semantic-level: Hypergraph Diffusion
        """

    def __init__(self,
                     bio_encoder,
                     topo_encoder,
                     semantic_encoder,
                     decoder,
                     embed_dim=256):
        super().__init__()

        self.bio_encoder = bio_encoder
        self.topo_encoder = topo_encoder
        self.semantic_encoder = semantic_encoder
        self.decoder = decoder

        # # ===== 新增：Gated Fusion =====（基于门控机制的融合）
        # self.gate = nn.Sequential(
        #     nn.Linear(embed_dim * 2, embed_dim),
        #     nn.Sigmoid())
        # === 重构损失权重（⚠️ 回到 d × d gated）===
        # self.drug_rec_weight = nn.Parameter(torch.rand(embed_dim, embed_dim))
        # self.cline_rec_weight = nn.Parameter(torch.rand(embed_dim, embed_dim))

        # # ===============================
        # # Cross-attention fusion module 加了一个cross atten
        # # ===============================
        # self.cross_attn = nn.MultiheadAttention(
        #     embed_dim=embed_dim,  # d
        #     num_heads=4,
        #     dropout=0.1,
        #     batch_first=True
        # # === 重构损失权重（⚠️ 回到 d × d cross atten）===
        # self.drug_rec_weight = nn.Parameter(torch.rand(embed_dim, embed_dim))
        # self.cline_rec_weight = nn.Parameter(torch.rand(embed_dim, embed_dim))

        # # === 重构损失权重（保持原逻辑）=== (仅仅原始的concat方案)
        self.drug_rec_weight = nn.Parameter(torch.rand(embed_dim * 2, embed_dim * 2))
        self.cline_rec_weight = nn.Parameter(torch.rand(embed_dim * 2, embed_dim * 2))
        self.reset_parameters()

        # ===============================
        # # Bilinear Fusion (Topology ⊗ Semantic)
        # # ===============================
        # self.lin_topo = nn.Linear(embed_dim, embed_dim, bias=False)
        # self.lin_sem = nn.Linear(embed_dim, embed_dim, bias=False)
        # self.lin_bi = nn.Linear(embed_dim, embed_dim, bias=False)
        # self.fusion_act = nn.LeakyReLU(0.2)
        # # === 重构损失权重（⚠️ 回到 d × d cross atten）===
        # self.drug_rec_weight = nn.Parameter(torch.rand(embed_dim, embed_dim))
        # self.cline_rec_weight = nn.Parameter(torch.rand(embed_dim, embed_dim))


    def reset_parameters(self):
        reset(self.bio_encoder)
        reset(self.topo_encoder)
        reset(self.semantic_encoder)
        reset(self.decoder)

    #修改forward函数 对其上述接口
    def forward(self,
                drug_feature,
                drug_adj,
                ibatch,
                gexpr_data,
                hyperedge_index,
                druga_id,
                drugb_id,
                cellline_id):

        # 1. 生物特征编码（保持不变）
        drug_embed, cell_embed = self.bio_encoder(
            drug_feature, drug_adj, ibatch, gexpr_data
        )
        X = torch.cat((drug_embed, cell_embed), dim=0)  # (|V|, d)

        # 2. Topology-level（Sheaf Hypergraph）
        Z_topo = self.topo_encoder(X, hyperedge_index)  # (|V|, d)

        # 3. Semantic-level（Hypergraph Diffusion）
        Z_sem = self.semantic_encoder(X, hyperedge_index)  # (|V|, d)

        # ======================================================
        # # 4. Bilinear Fusion (Topology + Semantic)
        # # ======================================================
        #
        # z_topo = self.lin_topo(Z_topo)  # (|V|, d)
        # z_sem = self.lin_sem(Z_sem)  # (|V|, d)
        # z_bi = self.lin_bi(Z_topo * Z_sem)  # (|V|, d)
        # graph_embed = self.fusion_act(
        #     z_topo + z_sem + z_bi
        # )  # (|V|, d)

        # 4. 拼接（唯一新增逻辑）
        graph_embed = torch.cat([Z_topo, Z_sem], dim=1)  # (|V|, 2d)  直接拼接

        # ##新增的模块
        # # 4. Gated Fusion（替代 concat）
        # # ======================================================
        # z_cat = torch.cat([Z_topo, Z_sem], dim=1)  # (|V|, 2d)
        # g = self.gate(z_cat)  # (|V|, d)
        # graph_embed = g * Z_sem + (1 - g) * Z_topo  # (|V|, d)

        # ======================================================
        # 4. Cross-attention Fusion (Topology ↔ Semantic)
        # ======================================================
        # # MultiheadAttention expects (B, L, D) 这一块换成了cross attention
        # Z_topo_attn = Z_topo.unsqueeze(0)  # (1, |V|, d)
        # Z_sem_attn = Z_sem.unsqueeze(0)  # (1, |V|, d)
        # # Topology queries Semantic
        # fused_embed, attn_weights = self.cross_attn(
        #     query=Z_topo_attn,
        #     key=Z_sem_attn,
        #     value=Z_sem_attn
        # )
        # graph_embed = fused_embed.squeeze(0) + Z_topo
        # # graph_embed = fused_embed.squeeze(0)  # (|V|, d)

        # #4. 添加了一个cross attention
        # q = Z_topo.unsqueeze(1)  # (N,1,d)
        # k = Z_sem.unsqueeze(1)
        # v = Z_sem.unsqueeze(1)
        # fused, _ = self.cross_attn(q, k, v)
        # graph_embed = fused.squeeze(1)

        # 5. 拆分 drug / cell（保持原逻辑）
        drug_num = drug_embed.size(0)
        # num_cline = cell_embed.size(0)

        drug_emb = graph_embed[:drug_num]
        cline_emb = graph_embed[drug_num:]

        # 6. 相似性重构损失（保持原逻辑）
        rec_drug = torch.sigmoid(
            drug_emb @ self.drug_rec_weight @ drug_emb.t()
        )

        # rec_drug = torch.sigmoid(torch.mm(torch.mm(drug_emb, self.drug_rec_weight), drug_emb.t()))

        rec_cline = torch.sigmoid(
            cline_emb @ self.cline_rec_weight @ cline_emb.t()
        )

        # 7. Decoder（输入维度已自动对齐）
        out = self.decoder(
            graph_embed,
            druga_id,
            drugb_id,
            cellline_id
        )

        return out, rec_drug, rec_cline
